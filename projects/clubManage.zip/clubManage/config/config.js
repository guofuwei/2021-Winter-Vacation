// 这里是数据库的配置信息
module.exports = {
    mysqlConfig: {
        host: "localhost",
        user: "clubmanage",
        password: "123456",
        database: "clubmanage"
    },
    secretKey: "This is a secert ^-^" //这边是加密时用到的密钥
}